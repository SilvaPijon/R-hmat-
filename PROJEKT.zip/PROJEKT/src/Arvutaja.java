public interface Arvutaja {

    String kokkuvõte(Isik isik);

    int arvutaIsiksuseProtsent(int isiksusePunktid, int kõikPunktidKokku);

    void küsimuseLisamineKüsimustikku(int number);




}
