import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class Küsimus {

    //ISENDIVÄLI JA KONSTRUKTOR ----------------------------------------------------------------------------------------

    private int number;
    private String kõlabJärgmiselt;
    private String[] vastusevariandid = new String[4];
    private String valitudVastus;
    private Isiksus punkteLähebIsiksusele;

    Küsimus(int number) {
        this.number = number;
        String[] kasutatavRida = sisseLugemine();
        kõlabJärgmiselt = kasutatavRida[0];
        for (int i = 0; i < vastusevariandid.length; i++) {
            String vastus = kasutatavRida[i+1];
            vastusevariandid[i] = vastus;
        }
    }

    //MEETODIVÄLI ------------------------------------------------------------------------------------------------------

    public String[] sisseLugemine() {
        try {
            String path = "tekstifailid\\" + "Küsimused.txt";
            File myObj = new File(path);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                if (Integer.parseInt(String.valueOf(data.charAt(0))) == number) {
                    return data.split("_");
                }
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("Tekkis viga! Küsimuste fail ei ole kättesaadav");
        }
        System.out.println("Midagi läks valesti!");
        return null;
    }

    // LISAMEETODID ----------------------------------------------------------------------------------------------------


    public void setValitudVastus(String valitudVastus) {
        this.valitudVastus = valitudVastus;
    }

    public String getValitudVastus() {
        return valitudVastus;
    }

    public void setPunkteLähebIsiksusele(Isiksus punkteLähebIsiksusele) {
        this.punkteLähebIsiksusele = punkteLähebIsiksusele;
    }

    public Isiksus getPunkteLähebIsiksusele() {
        return punkteLähebIsiksusele;
    }

    public String getKõlabJärgmiselt() {
        return kõlabJärgmiselt;
    }

    public int getNumber() {
        return number;
    }

    public String[] getVastusevariandid() {
        return vastusevariandid;
    }

    @Override
    public String toString() {
        return "Küsimus{" +
                "number=" + number +
                ", kõlabJärgmiselt='" + kõlabJärgmiselt + '\'' +
                ", vastusevariandid=" + Arrays.toString(vastusevariandid) +
                ", valitudVastus='" + valitudVastus + '\'' +
                ", punkteLähebIsiksusele=" + punkteLähebIsiksusele +
                '}';
    }
} //--------------------------------------------------------------------------------------------------------------------
