public interface Inimene {

    void lisaIsiksus(Isiksus isiksus);

    void näitaTulemus();

}
