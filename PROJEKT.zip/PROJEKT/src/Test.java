public class Test {

    public static void main(String[] args) {
        Isiksus katse = new Isiksus("Stabiilne", 0);
        System.out.println(katse.getIsiksuseKirjeldus());

        Küsimus küss = new Küsimus(2);
        System.out.println(küss.toString());;

    }
}
