import java.util.ArrayList;

public class Isik implements Inimene{

    //ISENDIVÄLI JA KONSTRUKTOR ----------------------------------------------------------------------------------------

    private int isikuVanus;
    private char sugu;
    private ArrayList<Isiksus> temaIsiksused = new ArrayList<>();

    Isik(int isikuVanus, char sugu) {
        this.isikuVanus = isikuVanus;
        this.sugu = Character.toUpperCase(sugu);
    }

    //MEETODIVÄLI ------------------------------------------------------------------------------------------------------

    public void lisaIsiksus(Isiksus isiksus) {
        temaIsiksused.add(isiksus);
    }

    public void näitaTulemus() {
        System.out.println("Sinu isiksusetüübid jagunevad järgmiselt: ");
        for (Isiksus isiksus : temaIsiksused)
            System.out.println("");
    }

    // LISAMEETODID ----------------------------------------------------------------------------------------------------

    public int getIsikuVanus() {
        return isikuVanus;
    }

    public char getSugu() {
        return sugu;
    }

    public ArrayList<Isiksus> getTemaIsiksused() {
        return temaIsiksused;
    }

    @Override
    public String toString() {
        return "Isik{" +
                "isikuVanus=" + isikuVanus +
                ", sugu=" + sugu +
                ", temaIsiksused=" + temaIsiksused +
                '}';
    }

} //--------------------------------------------------------------------------------------------------------------------