import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class Isiksus {

    //ISENDIVÄLI JA KONSTRUKTOR ----------------------------------------------------------------------------------------

    private String tüüp;
    private int isiksuseProtsent = 0;
    private String isiksuseKirjeldus = "";
    private int[] vahemikud;

    Isiksus(String tüüp, int isiksuseProtsent) {
        this.tüüp = tüüp.toUpperCase();
        this.isiksuseProtsent = isiksuseProtsent;
        määraUusKirjeldus(isiksuseProtsent);
        if (this.tüüp.equals("ANALÜÜSIV"))
            this.vahemikud = new int[]{0, 50, 100};
        else if (this.tüüp.equals("DOMINEERIV"))
            this.vahemikud = new int[]{0, 50, 75, 100};
        else if (this.tüüp.equals("SOTSIAALNE"))
            this.vahemikud = new int[]{0, 25, 50, 75, 100};
        else if (this.tüüp.equals("STABIILNE"))
            this.vahemikud = new int[]{0, 25, 50, 100};
        else System.out.println("Sisestatud tüüp ei sobi!");
    }

    //MEETODIVÄLI ------------------------------------------------------------------------------------------------------

    public void määraUusProtsent(int ümardatudProtsent) {
        setIsiksuseProtsent(ümardatudProtsent);
        määraUusKirjeldus(ümardatudProtsent);
    }

    public String määraUusKirjeldus(int protsent) {
        try {
            String iseloom = this.tüüp + "Iseloom";
            String path = "tekstifailid\\" + iseloom + "/" + iseloom + "-" + getIsiksuseProtsent() + "%.txt";
            File myObj = new File(path);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                this.isiksuseKirjeldus += data + "\n";
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("Tekkis viga! Kirjelduse fail ei ole kättesaadav");
        }
        return this.isiksuseKirjeldus;
    }

    // LISAMEETODID ----------------------------------------------------------------------------------------------------

    public int getIsiksuseProtsent() {
        return isiksuseProtsent;
    }

    public String getIsiksuseKirjeldus() {
        return isiksuseKirjeldus;
    }

    public int[] getVahemikud() {
        return vahemikud;
    }

    public String getTüüp() {
        return tüüp;
    }

    public void setIsiksuseProtsent(int isiksuseProtsent) {
        this.isiksuseProtsent = isiksuseProtsent;
    }

    public void setIsiksuseKirjeldus(String isiksuseKirjeldus) {
        this.isiksuseKirjeldus = isiksuseKirjeldus;
    }

    public void setTüüp(String tüüp) {
        this.tüüp = tüüp;
    }

    public void setVahemikud(int[] vahemikud) {
        this.vahemikud = vahemikud;
    }

    @Override
    public String toString() {
        return "Isiksus{" +
                "tüüp='" + tüüp + '\'' +
                ", isiksuseProtsent=" + isiksuseProtsent +
                ", isiksuseKirjeldus='" + isiksuseKirjeldus + '\'' +
                ", vahemikud=" + Arrays.toString(vahemikud) +
                '}';
    }

} //--------------------------------------------------------------------------------------------------------------------
