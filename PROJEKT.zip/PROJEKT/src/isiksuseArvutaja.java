import java.util.ArrayList;

public class isiksuseArvutaja implements Arvutaja {

    //ISENDIVÄLI JA KONSTRUKTOR ----------------------------------------------------------------------------------------

    private ArrayList<Küsimus> küsimustik = new ArrayList<>();




    //MEETODIVÄLI ------------------------------------------------------------------------------------------------------

    public String kokkuvõte(Isik isik) {

        //tagastab ühise teksti, mis sisaldab kõiki kirjeldusi vastavalt saadud protsentidele

    return null;
    }

    public int arvutaIsiksuseProtsent(int isiksusePunktid, int kõikPunktidKokku) {
        return isiksusePunktid/kõikPunktidKokku;
    }

    public void küsimuseLisamineKüsimustikku(int number) {
        küsimustik.add(new Küsimus(number));
    }

    // LISAMEETODID ----------------------------------------------------------------------------------------------------

} //--------------------------------------------------------------------------------------------------------------------
