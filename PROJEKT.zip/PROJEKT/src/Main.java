public class Main {

    public static void main(String[] args) {

        System.out.println("Tere tulmast mängu: Mis on sinu isiksus?");
        System.out.println("Mängu alustamiseks palun märgi oma vanus: ");
        System.out.println("Samuti märgi ka oma sugu (N või M): ");
        System.out.println("Mängureeglid on järgmised: ");





    }
}
