public class Domineeriv implements Isiksus{

    @Override
    public void teavitaKasutajat(int tähis){
        System.out.println("Oled "+ tähis + "% domineeriv isiksuse tüüp. " +
                "Sa eelistad olla meeskonna juht ning ei lase teistel väga oma arvamust või seisukohta muuta. " +
                "Sulle tundub, et sind saadab edu ainult korralikul ettevalmistusel ning piisava info omamisel. " +
                "Sa oled järjekindel ja edukas, sa tead täpselt, mis on sinu järgmine samm ning sa ei jäta kunagi muljet, " +
                "nagu sa ei saaks aru, mis toimub. Sulle meeldib võta vastutuse enda peale isegi siis, kui ei näe endas süüd. " +
                "Sinuga ei tasu kunagi vaielda, sest isegi ku isul pole õigus, sa ei saa lubada, et sinu autoriteet teiste seal langeks." );
    }
}
