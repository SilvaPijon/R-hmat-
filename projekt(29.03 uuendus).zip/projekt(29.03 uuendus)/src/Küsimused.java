import java.util.Scanner;

public class Küsimused {

    public void küsiKüsimused(Isik isik){
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("1) Milline värv nendest meeldib sulle rohkem:\n" +
                "a) Sinine\n" +
                "b) Punane\n" +
                "c) Kollane\n" +
                "d) Roheline\n");
        String vastus = myObj.nextLine();
        võtaVastus(vastus, isik);
        System.out.println("2) Milline aine meeldis sulle koolis kõige rohkem:\n" +
                "a) Matemaatika\n" +
                "b) Muusikaõpetus\n" +
                "c) Kehaline kasvatus\n" +
                "d) Inglise keel\n");
        vastus = myObj.nextLine();
        võtaVastus(vastus, isik);
        System.out.println("3) Mida on sinu foobia:\n" +
                "a) Ämblikud, maod, putukad\n" +
                "b) Kõrgus\n" +
                "c) Sügav vesi\n" +
                "d) TUlevikukartus\n");
        vastus = myObj.nextLine();
        võtaVastus(vastus, isik);
        System.out.println("4) Millest sa unistad kõige rohkem:\n" +
                "a) Palju raha\n" +
                "b) Suur ja ilus kodu\n" +
                "c) Kiire ja kallis auto\n" +
                "d) Amet, mis mulle meeldib\n");
        vastus = myObj.nextLine();
        võtaVastus(vastus, isik);
        System.out.println("5) Sinu lemmik filmižanr:\n" +
                "a) Õudukad\n" +
                "b) Komöödiad\n" +
                "c) Seiklusfilmid\n" +
                "d) Draamad\n");
        vastus = myObj.nextLine();
        võtaVastus(vastus, isik);



    }
    public void võtaVastus(String vastus, Isik isik){
        if (vastus.equalsIgnoreCase("a")){
            isik.suurendaA();
        }
        if (vastus.equalsIgnoreCase("b")){
            isik.suurendaB();
        }
        if (vastus.equalsIgnoreCase("c")){
            isik.suurendaC();
        }
        if (vastus.equalsIgnoreCase("d")){
            isik.suurendaD();
        }

    }
}
