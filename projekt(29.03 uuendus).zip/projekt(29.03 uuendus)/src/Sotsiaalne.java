public class Sotsiaalne implements Isiksus {

    @Override
    public void teavitaKasutajat(int tähis){
        System.out.println("Oled "+ tähis + "% sotsiaalne isiksuse tüüp. " +
                "Inimesed on sinu energiaallikas. Sa ei suuda veeta ühtegi päeva inimkontaktita ning sellepärast oled sa esimene inimene, " +
                "keda peole kaasa kustutakse. Sa ei karda kedagi ega midagi ning oled alati truu ja avatud teiste inimestega. " +
                "Sa oskad rääkida oma elust ning oled inspiratsiooniks inimestele, kes mingil põhjusel ei oma samasugust julgust. " +
                "Sul on alati olemas arvamus ning sa ei karda seda väljendada. Sa oskad anda inimestele konstruktiivset tagasisidet ning sinust " +
                "saadakse aru. Isegi siis, kui sa mõnda asja ei oska, sinu peamine supervõim on olla kameeleon ning inimeste arvates oled multitalent, sest " +
                "mida sa ka ei teeks, saadab sind alati teatud sarm ja positiivsus.");
    }
}
