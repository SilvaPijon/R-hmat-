import java.util.Scanner;

public class KüsimusedN extends Küsimused{
    public void küsiKüsimused(Isik isik) {
        super.küsiKüsimused(isik);
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("1) Kui su püksid rebenevad keset tänaval kõndimist:\n" +
                "a) Tellid takso ja sõidad koheselt koju\n" +
                "b) Kõnnid sihtkohta edasi nagu polekski midagi olnud\n" +
                "c) Satud paanikasse ja hakkad nutma\n" +
                "d) Katad kinni ja jooksed lähimasse riidepoodi\n");
        String vastus = myObj.nextLine();
        võtaVastus(vastus, isik);
        System.out.println("2) Kui oled dieedil ning tuttav pakub sulle brownie´t:\n" +
                "a) Mulle ei maitse šokolaad\n" +
                "b) Mis dieet?\n" +
                "c) Sööd ära ja küsid, kas kuskil on neid veel\n" +
                "d) Proovid väikese tükikese\n");
        vastus = myObj.nextLine();
        võtaVastus(vastus, isik);
        System.out.println("3) Jäid bussist maha:\n" +
                "a) Jooksed talle järgi ja karjud, et jääks seisma\n" +
                "b) Ootad ära järgmise\n" +
                "c) Lööd käega ja lähed jala\n" +
                "d) Sa ei jää kunagi bussidest maha\n");
        vastus = myObj.nextLine();
        võtaVastus(vastus, isik);
        System.out.println("3) Riigis kehtestati eriolukord, kuidas lahutad meelt?:\n" +
                "a) Loed läbi kõik raamatud, mis kodus olemas\n" +
                "b) Proovid uusi retsepte\n" +
                "c) Vaatad filme\n" +
                "d) Lähed jalutama või teed trenni\n");
        vastus = myObj.nextLine();
        võtaVastus(vastus, isik);
        System.out.println("3) Millist puhkusetüüpi sooviksid hetkel:\n" +
                "a) Rand, vesi ja palmipuud\n" +
                "b) Loodus ja loomad\n" +
                "c) Mäed ja talvesport\n" +
                "d) Linnad ja kultuur\n");
        vastus = myObj.nextLine();
        võtaVastus(vastus, isik);
    }
}
