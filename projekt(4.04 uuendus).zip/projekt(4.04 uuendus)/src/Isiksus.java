public interface Isiksus {
    public void teavitaKasutajat(int tähis);
}
