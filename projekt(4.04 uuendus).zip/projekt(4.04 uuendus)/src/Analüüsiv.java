public class Analüüsiv implements Isiksus{

    @Override
    public void teavitaKasutajat(int tähis) {
        System.out.println("Oled "+ tähis + "% alaüüsiv isiksuse tüüp. Sa eelistad hoiduda otsuste vastuvõtmisest." +
                "Enne tegutsemist sul on vaja veenduda, et aeg ja olukord oleksid õiged, sest sa mõistad, et igal ajsal on omad tagajärjed." +
                "Sul on alati olemas plaan, isegi siis, kui sa teistele seda ei maini. Sa hoidud konfliktidest ja ebavajalikest kokkusaamistest teiste isikutega." +
                "Sa hindad seda, mida oled saavutanud ning tead, mida pead tegema selleks, et edasi liikuda ja areneda.");





    }
}
