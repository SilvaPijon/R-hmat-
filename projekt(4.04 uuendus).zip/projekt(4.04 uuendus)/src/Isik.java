import java.util.Scanner;

public class Isik {
    public String nimi = "";
    public String sugu = "";
    public Küsimused küsimused;

    public int a;
    public int b;
    public int c;
    public int d;

    public Isik() {
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Palun sisesta enda nimi: ");
        this.nimi = myObj.nextLine();
        boolean onMees = false;
        boolean onNaine = false;
        String valitudSugu;
        while (!onMees && !onNaine) {
            System.out.println("Palun sisesta enda sugu: ");
            valitudSugu  = myObj.nextLine();
            if (valitudSugu.equalsIgnoreCase("M")) {
                onMees = true;
                break;
            }
            else if (valitudSugu.equalsIgnoreCase("N")) {
                onNaine = true;
                break;
            }
        }

        Küsimused küsimused;
        if (onMees)
            küsimused = new KüsimusedM();
        else if (onNaine)
            küsimused = new KüsimusedN();
        else
            küsimused = new Küsimused();
        this.küsimused = küsimused;

        this.a = 0;
        this.b = 0;
        this.c = 0;
        this.d = 0;
    }

    public Küsimused getKüsimused() {
        return küsimused;
    }

    public int getA() {
        return a;
    }

    public int getB() {
        return b;
    }

    public int getC() {
        return c;
    }

    public int getD() {
        return d;
    }

    public void suurendaA(){
        a++;
    }
    public void suurendaB(){
        b++;
    }
    public void suurendaC(){
        c++;
    }

    @Override
    public String toString() {
        return "Isik{" +
                "nimi='" + nimi + '\'' +
                ", sugu='" + sugu + '\'' +
                ", a=" + a +
                ", b=" + b +
                ", c=" + c +
                ", d=" + d +
                '}';
    }

    public void suurendaD(){
        d++;
    }


}
