public class Stabiilne implements Isiksus{


    @Override
    public void teavitaKasutajat(int tähis){
        System.out.println("Oled "+ tähis + "% stabiilne isiksuse tüüp. " +
                "Sa oled enesekindel ning omas sisemist rahu igas olukorras. Sa suudad igati vältida arusaamatusi teiste inimestega" +
                "ning sul ei teki probleeme inimeste rahustamisega. Oled tihti see inimene, kes kaklusi peatab. " +
                "Sa mõistad, et maailm ei ole täiuslik ning tuleb leppida ka ebameeldivate hetkedega elus. Kuid need ei valmista sulle kunagi " +
                "pettumust, sest sa näed seda pigem väljakutsena kui takistusena. Su sõbrad usaldavad sind ning nad teavad, millises " +
                "kohvikus võib sind päikselisel suvepäeval kohvi joomas näha.");
    }

}
