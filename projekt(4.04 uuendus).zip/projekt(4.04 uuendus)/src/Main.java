public class Main {

    public static void main(String[] args) {
        System.out.println("\nTere tulemast isiksuse testi!\n");
        // Loome programmitööks vastavad objektid
        Isik isik = new Isik();
        Küsimused küsimused;
        Arvutaja arvutaja = new Arvutaja();
        // Alustame Küsimustikuga
        System.out.println("\nJärgmisena pead vastama 10-le küsimusele" +
                "\nning sinu vastustest lähtudes arvutab programm välja" +
                "\nsinu isiksuse tüüpide jagunemise!\n" +
                "\nMÄNG ALGAB NÜÜD!\n");
        isik.getKüsimused().küsiKüsimused(isik);
        int[] protsendid = arvutaja.protsent(isik);

        System.out.println("\nTULEMUS ON KÄES!" +
                "\nSinu isiksusetüübid jagunesid järgmiselt: \n");

        Isiksus stabiilne = new Stabiilne();
        stabiilne.teavitaKasutajat(protsendid[0]);


        Isiksus analüüsiv = new Analüüsiv();
        analüüsiv.teavitaKasutajat(protsendid[1]);

        Isiksus domineeriv = new Domineeriv();
        domineeriv.teavitaKasutajat(protsendid[2]);

        Isiksus sotsiaalne = new Sotsiaalne();
        sotsiaalne.teavitaKasutajat(protsendid[3]);


    }

}
